16x16 RPG Icons - Pack 1 - Items and Skills
Free Sample of 140 icons
by 7Soul - @7SoulDesign
https://7soul.itch.io

The icons in this pack are free for commercial use